import express from "express";
import dotenv from "dotenv";
import axios from "axios";
import { AuthorizationCode } from "simple-oauth2";
import { dirname } from "path";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const __dirname=dirname(fileURLToPath(import.meta.url));
const app=express();
const port=3000;
app.use(express.static(path.join(__dirname, "client")));
const client = new AuthorizationCode({
    client: {

        id: process.env.GOOGLE_CLIENT_ID,
        
        secret: process.env.GOOGLE_CLIENT_SECRET,
        
        },
        auth: {

            tokenHost: "https://accounts.google.com",
            
            authorizePath: "/o/oauth2/v2/auth",
            
            tokenPath: "https://oauth2.googleapis.com/token",
            
            },
            
            });
            const authorizationUri = client.authorizeURL({
                redirect_uri: process.env.REDIRECT_URI,
                scope: ["openid", "profile", "email"],
                state: Math.random().toString(36).substring(7),

});
app.get("/", (req, res) => {

    res.redirect(authorizationUri);
    
    });
    app.get("/callback", async (req, res) => { 
        const { code } = req.query;
        try {

            const tokenParams = {
            code,
            redirect_uri: process.env.REDIRECT_URI,
            scope: "openid profile email",
            
            };
            const accessToken = await client.getToken(tokenParams);
            const token = accessToken.token;
            const userInfo = await axios.get(

                "https://www.googleapis.com/oauth2/v3/userinfo",
            {
            headers: {
            Authorization:` Bearer ${token.access_token}`,
            },
        }
    );
    res.redirect("../client/index.html");
} catch (error) {
    console.error("Error exchanging code for token:", error.message); res.status(500).json({ error: "Authentication failed" });

}

});
app.get("../client/index.html", (req, res) => {
    res.sendFile(path.join(_dirname, "client", "index.html"));

});
app.listen(port, () => { 

    console.log(`Aplikacja działa na porcie ${port}`); 

}); 

 